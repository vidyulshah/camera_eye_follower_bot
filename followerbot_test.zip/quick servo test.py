import time
from board import SCL, SDA
import busio
from adafruit_pca9685 import PCA9685
from adafruit_motor import servo

# -----------------------------
# I2C Setup for PCA9685
# -----------------------------
i2c = busio.I2C(SCL, SDA)
pca = PCA9685(i2c)
pca.frequency = 60  # Standard servo frequency

# -----------------------------
# Servo Definitions
# -----------------------------
servos = {
    "LR": servo.Servo(pca.channels[0]),   # Eye left-right
    "UD": servo.Servo(pca.channels[1]),   # Eye up-down
    "TL": servo.Servo(pca.channels[2]),   # Top-left eyelid
    "BaseX": servo.Servo(pca.channels[3]),# Neck horizontal
    "TR": servo.Servo(pca.channels[4]),   # Top-right eyelid
    "BaseY": servo.Servo(pca.channels[5]) # Neck vertical
}

# -----------------------------
# Servo Motion Limits
# -----------------------------
servo_limits = {
    "LR": (40, 140),
    "UD": (40, 140),
    "TL": (70, 120),
    "TR": (120, 70),
    "BaseX": (30, 150),
    "BaseY": (10, 60),
}

# -----------------------------
# Servo Starting Positions
# -----------------------------
servo_starts = {
    "LR": 90,
    "UD": 90,
    "TL": 90,
    "TR": 90,
    "BaseX": 90,
    "BaseY": 30,
}

# -----------------------------
# Servo Test Function
# -----------------------------
def test_servos():
    print("Starting servo verification test...\n")
    for name, s in servos.items():
        min_angle, max_angle = servo_limits[name]
        start_angle = servo_starts.get(name, 90)
        print(f"Testing {name}: moving from {min_angle}° → {max_angle}° → {start_angle}°")

        # Move to min angle
        s.angle = min_angle
        time.sleep(0.8)

        # Move to max angle
        s.angle = max_angle
        time.sleep(0.8)

        # Return to start angle
        s.angle = start_angle
        time.sleep(0.8)

        print(f"✅ {name} test complete.\n")

    print("All servo tests finished successfully!")

# -----------------------------
# Main Entry Point
# -----------------------------
if __name__ == "__main__":
    try:
        test_servos()
    except KeyboardInterrupt:
        print("Test interrupted by user.")
    finally:
        # Move all servos back to safe neutral position
        for name, s in servos.items():
            s.angle = servo_starts.get(name, 90)
        pca.deinit()
        print("Servos returned to safe positions. PCA9685 released.")

