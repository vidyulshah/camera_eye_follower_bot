import time
import random
from board import SCL, SDA
import busio
from adafruit_pca9685 import PCA9685
from adafruit_motor import servo

# -----------------------------
# I2C Setup for PCA9685
# -----------------------------
i2c = busio.I2C(SCL, SDA)
pca = PCA9685(i2c)
pca.frequency = 60  # Standard servo frequency

# -----------------------------
# Servo Definitions
# -----------------------------
servos = {
    # LR is logical only, channel 0 servo will not move
    "UD": servo.Servo(pca.channels[1]),
    "TL": servo.Servo(pca.channels[2]),
    "BaseX": servo.Servo(pca.channels[3]),
    "TR": servo.Servo(pca.channels[4]),
    "BaseY": servo.Servo(pca.channels[5]),
}

# -----------------------------
# Servo Limits and Targets
# -----------------------------
servo_limits = {
    "LR": (40, 140),    # Eye left-right (logical only)
    "UD": (40, 140),    # Eye up-down
    "TL": (70, 90),    # Top-left eyelid
    "TR": (90, 70),    # Top-right eyelid (reverse direction)
    "BaseX": (30, 150), # Neck horizontal
    "BaseY": (10, 45),  # Neck vertical
}

servo_targets = {
    "LR": 90,        # Logical target for eye left-right
    "UD": 90,        # Eye up-down
    "BaseX": 90,     # Neck horizontal
    "BaseY": 30,     # Neck vertical
    "BXTarget": 90,  # Target for BaseX
    "BYTarget": 30,  # Target for BaseY
}

deadzone_eye = 25
deadzone_neck = 20
neck_timer_ms = 1200
neck_trigger_time = 0
neck_flag = False
Kp = 0.03
last_update = int(time.time() * 1000)

# -----------------------------
# Initialize all servos at target angles
# -----------------------------
for name, s in servos.items():
    if name in servo_targets:
        s.angle = servo_targets[name]

# -----------------------------
# Blink and Lid Sync Functions
# -----------------------------
def blink():
    servos["TL"].angle = 90
    servos["TR"].angle = 90

def lid_sync():
    ud_min, ud_max = servo_limits["UD"]
    tl_min, tl_max = servo_limits["TL"]
    tr_min, tr_max = servo_limits["TR"]

    ud_progress = (servo_targets["UD"] - ud_min) / (ud_max - ud_min)
   
    tl_target = tl_max - ((tl_max - tl_min) * (0.5 * (1 - ud_progress))) - 10
    tr_target = tr_max + ((tr_min - tr_max) * (0.5 * (1 - ud_progress))) + 10
   
    servos["TL"].angle = tl_target
    servos["TR"].angle = tr_target

# -----------------------------
# Move Eyes Function
# -----------------------------
def move_target(servo_name, error):
    if abs(error) <= deadzone_eye:
        return
    if error < 0:
        error -= deadzone_eye
    elif error > 0:
        error += deadzone_eye
    
    step = int(Kp * error)
    if step == 0:
        step = 1 if error > 0 else -1

    new_target = servo_targets[servo_name] + step
    new_target = max(servo_limits[servo_name][0], min(servo_limits[servo_name][1], new_target))
    servo_targets[servo_name] = new_target
    
    # Only move the physical servo if it exists
    if servo_name in servos:
        servos[servo_name].angle = new_target

# -----------------------------
# Neck Movement Functions
# -----------------------------
def neck_target(LR, UD):
    servo_targets["BXTarget"] = LR
    servo_targets["BYTarget"] = 90 - ((90 - UD) * 0.6)

def neck_smooth_move(speed_deg_per_s=60):
    global last_update
    now = int(time.time() * 1000)
    dt = now - last_update
    last_update = now

    step_size = (speed_deg_per_s * dt) / 1000.0

    # BaseX
    dx = servo_targets["BXTarget"] - servo_targets["BaseX"]
    if abs(dx) <= step_size:
        servo_targets["BaseX"] = servo_targets["BXTarget"]
    else:
        servo_targets["BaseX"] += step_size if dx > 0 else -step_size

    # BaseY
    dy = servo_targets["BYTarget"] - servo_targets["BaseY"]
    if abs(dy) <= step_size:
        servo_targets["BaseY"] = servo_targets["BYTarget"]
    else:
        servo_targets["BaseY"] += step_size if dy > 0 else -step_size

    servos["BaseX"].angle = int(servo_targets["BaseX"])
    servos["BaseY"].angle = int(servo_targets["BaseY"])

# -----------------------------
# Main Loop Function
# -----------------------------
def eye_error_message(err_x, err_y):
    global neck_flag, neck_trigger_time
    
    error_x = err_x
    error_y = err_y

    # LR is logical only; does not move physical servo
    move_target("LR", -error_x)
    move_target("UD", error_y)

    if random.randint(0, 60) < 1:
        blink()
        time.sleep(0.06)
        lid_sync()

    lid_sync()

    # Trigger neck movement if eye targets deviate
    if abs(servo_targets["UD"] - 90) >= deadzone_neck or abs(servo_targets["LR"] - 90) >= deadzone_neck:
        if not neck_flag:
            neck_trigger_time = int(time.time() * 1000)
            neck_flag = True
        if neck_flag and (int(time.time() * 1000) - neck_trigger_time) >= neck_timer_ms:
            neck_target(servo_targets["LR"], servo_targets["UD"])
            neck_flag = False

    neck_smooth_move()
    time.sleep(0.02)
'''
# -----------------------------
# Example simulation
# -----------------------------
while True:
    # Simulate random eye errors
    err_x = random.randint(-30, 30)
    err_y = random.randint(-30, 30)
    eye_error_message(err_x, err_y)
'''
