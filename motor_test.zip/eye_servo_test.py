import time
import random
from board import SCL, SDA
import busio
from adafruit_pca9685 import PCA9685
from adafruit_motor import servo

# -----------------------------
# I2C Setup for PCA9685
# -----------------------------
i2c = busio.I2C(SCL, SDA)
pca = PCA9685(i2c)
pca.frequency = 60  # Standard servo frequency

# -----------------------------
# Servo Definitions
# -----------------------------
servos = {
    "LR": servo.Servo(pca.channels[0]),
    "UD": servo.Servo(pca.channels[1]),
    "TL": servo.Servo(pca.channels[2]),
    "BaseX": servo.Servo(pca.channels[3]),
    "TR": servo.Servo(pca.channels[4]),
    "BaseY": servo.Servo(pca.channels[5]),
}

# -----------------------------
# Servo Limits and Targets
# -----------------------------
servo_limits = {
    "LR": (40, 140),  
    "UD": (40, 140),
    "TL": (90, 170),
    "BaseX": (10, 170),
    "TR": (90, 10),
    "BaseY": (40, 140),
}

servo_targets = {
    "LR": 90,
    "UD": 90,
    "BaseX": 90,
    "BaseY": 90,
    "BXTarget": 90,
    "BYTarget": 90,
}

deadzone_eye = 25
deadzone_neck = 20
neck_timer_ms = 1200
neck_trigger_time = 0
neck_flag = False
Kp = 0.03
last_update = time.ticks_ms()
error_x = 0
error_y = 0

# -----------------------------
# Initialize all servos at 90°
# -----------------------------
for name, s in servos.items():
    s.angle = 90

# -----------------------------
# Blink and Lid Sync Functions
# -----------------------------
def blink():
    servos["TL"].angle = 90
    servos["TR"].angle = 90

def lid_sync():
    ud_min, ud_max = servo_limits["UD"]
    tl_min, tl_max = servo_limits["TL"]
    tr_min, tr_max = servo_limits["TR"]

    ud_progress = (servo_targets["UD"] - ud_min) / (ud_max - ud_min)
   
    tl_target = tl_max - ((tl_max - tl_min) * (0.5 * (1 - ud_progress))) - 10
    tr_target = tr_max + ((tr_min - tr_max) * (0.5 * (1 - ud_progress))) + 10
   
    servos["TL"].angle = tl_target
    servos["TR"].angle = tr_target

# -----------------------------
# Move Eyes Function
# -----------------------------
def move_target(servo_name, error):
    if abs(error) <= deadzone_eye:
        return
    if error < 0:
        error -= deadzone_eye
    elif error > 0:
        error += deadzone_eye
    
    step = int(Kp * error)
    if step == 0:
        step = 1 if error > 0 else -1

    new_target = servo_targets[servo_name] + step
    new_target = max(servo_limits[servo_name][0], min(servo_limits[servo_name][1], new_target))
    servo_targets[servo_name] = new_target
    servos[servo_name].angle = new_target

# -----------------------------
# Neck Movement Functions
# -----------------------------
def neck_target(LR, UD):
    servo_targets["BXTarget"] = LR
    servo_targets["BYTarget"] = 90 - ((90 - UD) * 0.6)

def neck_smooth_move(speed_deg_per_s=60):
    global last_update
    now = time.ticks_ms()
    dt = time.ticks_diff(now, last_update)
    last_update = now

    step_size = (speed_deg_per_s * dt) / 1000.0

    # BaseX
    dx = servo_targets["BXTarget"] - servo_targets["BaseX"]
    if abs(dx) <= step_size:
        servo_targets["BaseX"] = servo_targets["BXTarget"]
    else:
        servo_targets["BaseX"] += step_size if dx > 0 else -step_size

    # BaseY
    dy = servo_targets["BYTarget"] - servo_targets["BaseY"]
    if abs(dy) <= step_size:
        servo_targets["BaseY"] = servo_targets["BYTarget"]
    else:
        servo_targets["BaseY"] += step_size if dy > 0 else -step_size

    servos["BaseX"].angle = int(servo_targets["BaseX"])
    servos["BaseY"].angle = int(servo_targets["BaseY"])

# -----------------------------
# Main Loop (replace stdin input with your own error source)
# -----------------------------
while True:
    # Example: Random movement simulation
    error_x = random.randint(-50, 50)
    error_y = random.randint(-50, 50)

    move_target("LR", -error_x)
    move_target("UD", error_y)

    if random.randint(0, 60) < 1:
        blink()
        time.sleep(0.06)
        lid_sync()

    lid_sync()

    if abs(servo_targets["UD"] - 90) >= deadzone_neck or abs(servo_targets["LR"] - 90) >= deadzone_neck:
        if not neck_flag:
            neck_trigger_time = time.ticks_ms()
            neck_flag = True
        if neck_flag and (time.ticks_ms() - neck_trigger_time) >= neck_timer_ms:
            neck_target(servo_targets["LR"], servo_targets["UD"])
            neck_flag = False

    neck_smooth_move()
    time.sleep(0.02)
