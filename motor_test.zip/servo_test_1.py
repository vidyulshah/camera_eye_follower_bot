import time
from board import SCL, SDA
import busio
from adafruit_pca9685 import PCA9685
from adafruit_motor import servo

# Create I2C bus interface
i2c = busio.I2C(SCL, SDA)

# Create PCA9685 instance
pca = PCA9685(i2c)
pca.frequency = 60  # Standard servo frequency (50–60 Hz)

# Create servo objects on channels 0 and 1
servo0 = servo.Servo(pca.channels[5])  # Servo 1 connected to channel 0
'''
servo1 = servo.Servo(pca.channels[1])  # Servo 2 connected to channel 1
servo2 = servo.Servo(pca.channels[2])
servo3 = servo.Servo(pca.channels[3])  # Servo 1 connected to channel 0
servo4 = servo.Servo(pca.channels[4])  # Servo 2 connected to channel 1
servo5 = servo.Servo(pca.channels[5])
'''
servo0.angle=30
'''
servo1.angle=90
servo2.angle=90
servo3.angle=90
servo4.angle=90
servo5.angle=30
'''

time.sleep(2)

print("Moving two servos between 0° and 180°...")
while True:
    # Move both servos from 0° to 180°
    for angle in range(10, 51, 5):
        servo0.angle = angle
       # servo1.angle = 180-angle
        time.sleep(0.1)
    
    # Move both servos from 180° back to 0°
    for angle in range(50, 9, -5):
        servo0.angle = angle
        #servo1.angle = 180-angle
        time.sleep(0.1)

